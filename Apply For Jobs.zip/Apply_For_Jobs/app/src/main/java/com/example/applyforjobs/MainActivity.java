package com.example.applyforjobs;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import static com.example.applyforjobs.R.color.btnText;

public class MainActivity extends AppCompatActivity {

    ImageView imageview1, imageview2;
    TextInputEditText email, password;
    MaterialButton loginbtn;
    TextView sigup;
    ProgressBar progressbar;
    FirebaseAuth firebaseAuth;
    TextInputLayout emaillay,passwordlay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageview1 = findViewById(R.id.imageView1);
        imageview2 = findViewById(R.id.imageView2);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        loginbtn = findViewById(R.id.login);
        sigup = findViewById(R.id.signup);
        progressbar = findViewById(R.id.progressBar);
        firebaseAuth = firebaseAuth.getInstance();
        emaillay = findViewById(R.id.editText1);
        passwordlay = findViewById(R.id.editText2);


        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                LoginUserProcess();
            }
        });
        sigup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,Signup_page.class));
            }
        });
    }
    //caller loginbtn onclick
    void LoginUserProcess() {
        String Email = email.getText().toString().trim();
        String Password = password.getText().toString().trim();
        if (Email.isEmpty() && !(Patterns.EMAIL_ADDRESS.matcher(Email).matches()))
        {
            emaillay.setError("Invalid E-mail");
            emaillay.requestFocus();
            return;
        }
        if (Password.isEmpty() && Password.length()<6)
        {
            emaillay.setError(null);
            passwordlay.setError("Invalid Password");
            passwordlay.requestFocus();
            return;
        }
         passwordlay.setError(null);
         loginbtn.setText("");
         loginbtn.setEnabled(false);
         progressbar.setVisibility(View.VISIBLE);
         firebaseAuth.signInWithEmailAndPassword(Email, Password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            emailVerificationStatus();
                        } else {
                            Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            loginbtn.setText("Login");
                            loginbtn.setEnabled(true);
                            progressbar.setVisibility(View.GONE);
                        }
                    }
                });
    }
    //caller LoginUserProcess oncomplete
    public void emailVerificationStatus(){
        FirebaseUser firebaseUser=firebaseAuth.getCurrentUser();
        Boolean emailflag=firebaseUser.isEmailVerified();
        if(emailflag){
            startActivity(new Intent(MainActivity.this,Homepage.class));
            loginbtn.setEnabled(true);
            loginbtn.setText("Login");
            progressbar.setVisibility(View.GONE);
            MainActivity.this.finish();
        }
        else{
            Toast.makeText(this, "Please Verify Your Email", Toast.LENGTH_SHORT).show();
            firebaseAuth.signOut();
            loginbtn.setText("Login");
            progressbar.setVisibility(View.GONE);

        }
    }
    //caller addTextChangeListner

    @Override
    public void onBackPressed() {
        Intent a = new Intent(Intent.ACTION_MAIN);
        a.addCategory(Intent.CATEGORY_HOME);
        a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(a);
    }
}


