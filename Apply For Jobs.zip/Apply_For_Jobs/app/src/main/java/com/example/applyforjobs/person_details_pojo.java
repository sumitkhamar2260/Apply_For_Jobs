package com.example.applyforjobs;

public class person_details_pojo {
    String name,address,state,city,mob,email,dob;
    public person_details_pojo(String name,String address,String state,String  city,String mob,String  email,String  dob){
        this.name=name;
        this.address=address;
        this.state=state;
        this.city=city;
        this.mob=mob;
        this.email=email;
        this.dob=dob;
    }
}
